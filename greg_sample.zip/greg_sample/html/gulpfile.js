var gulp  = require('gulp');
var sass  = require('gulp-sass');
var watch = require('gulp-watch');
var autoprefixer = require('gulp-autoprefixer');

gulp.task('sass', function () {
    gulp.src('sass/app.scss')
        .pipe(sass())
        .pipe(gulp.dest('css'));
});

gulp.task('prefix', function () {
    return gulp.src('css/app.css')
        .pipe(autoprefixer({
            browsers: ['last 15 versions'],
            cascade: true
        }))
        .pipe(gulp.dest('css'));
});

gulp.task('default', ['sass', 'autoprefixer'], function() {
  //other stuff
});

gulp.task('watch', function() {
    //gulp.watch('js/*.js', ['lint', 'scripts']);
    gulp.watch('sass/**/*.scss', ['sass']);
});